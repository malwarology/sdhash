package sdhash

import (
	"encoding/base64"
	"fmt"
	"os"
	"strings"
	"testing"
)

// Regression test index
//
// Issue 1 — Hash Mismatch Between Reference Implementation and Go Implementation
//    https://github.com/eciavatta/sdhash/issues/1
// ├── 00010000  Stream and DD parsed score in range
// ├── 00020000  Round-trip stream reference
// └── 00030000  Round-trip DD reference
//
// Issue 2 — Feature density detection for degenerate stream mode digests
//    https://github.com/malwarology/sdhash/issues/2
// └── 00040000  DD mode no false positive
//
// Issue 3 — Unbounded goroutine spawning in generateBlockSdbf
//    https://github.com/malwarology/sdhash/issues/3
// └── 00050000  High block count DD mode
//
// Issue 4 — Unbounded memory allocation in ParseSdbfFromString
//    https://github.com/malwarology/sdhash/issues/4
// ├── 00060000  Parse oversized bfCount
// └── 00070000  Parse zero bfSize
//
// Issue 10 — ParseSdbfFromString panics on truncated base64 payload
//    https://github.com/malwarology/sdhash/issues/10
// ├── 00080000  Parse truncated stream buffer
// ├── 00090000  Parse stream lastCount exceeds maxElem
// ├── 00100000  Parse DD block too short
// └── 00110000  Parse DD element count exceeds maxElem
//
// Issue 11 — BfSize exported as mutable var but hardwired to 256 throughout
//    https://github.com/malwarology/sdhash/issues/11
// └── 00120000  Parse unsupported bfSize
//
// Issue 14 — New retains caller's slice without copying
//    https://github.com/malwarology/sdhash/issues/14
// └── 00130000  Buffer mutation after factory creation
//
// Issue 15 — DD parsing fails on digests without trailing newline
//    https://github.com/malwarology/sdhash/issues/15
// └── 00140000  DD parse without trailing newline
//
// Issue 17 — Compare panics on nil or foreign Sdbf implementation
//    https://github.com/malwarology/sdhash/issues/17
// ├── 00150000  Compare with nil Sdbf returns -1
// └── 00160000  Compare with foreign Sdbf implementation returns -1
//
// Issue 19 — Unconstrained maxElem enables uint32 overflow in Compare
//    https://github.com/malwarology/sdhash/issues/19
// ├── 00170000  Parse maxElem overflow (uint32 wraparound)
// └── 00180000  Parse maxElem zero
//
// Issue 20 — Inner while loop evaluates array access before bounds guard
//    https://github.com/malwarology/sdhash/issues/20
// └── 00190000  generateChunkScores inner while loop OOB
//
// Issue 21 — WithBlockSize accepts values below PopWinSize causing underflow panic
//    https://github.com/malwarology/sdhash/issues/21
// └── 00200000  Small block size uint64 underflow
//
// Issue 31 — ParseSdbfFromString ddBlockSize silently truncated from uint64 to uint32
//    https://github.com/malwarology/sdhash/issues/31
// └── 00210000  DD ddBlockSize uint64 to uint32 truncation
//
// Issue 43 — sdbfScore mixes -1 sentinel returns from sdbfMaxScore into the score sum, corrupting results
//    https://github.com/malwarology/sdhash/issues/43
// ├── 00220000  Stream mode degenerate pair returns score 0 and ok false
// └── 00230000  DD mode degenerate pair returns score 0 and ok false
//
// Issue 57 — generateChunkScores double-counts positions in equal-rank runs
//    https://github.com/malwarology/sdhash/issues/57
// ├── 00240000  Reference equivalence: high-entropy inputs
// ├── 00250000  Reference equivalence: tie-heavy inputs
// ├── 00260000  Reference equivalence: zero-laden inputs
// ├── 00270000  Reference equivalence: persistent-min inputs
// ├── 00280000  Reference equivalence: monotonic inputs
// ├── 00290000  Reference equivalence: all-equal inputs
// ├── 00300000  Reference equivalence: all-zero inputs
// ├── 00310000  Golden: high-entropy single interior minimum
// ├── 00320000  Golden: tie-heavy rightmost-of-first-run selection
// ├── 00330000  Golden: zero-laden zero-minimum skipped
// ├── 00340000  Golden: persistent-min single position, no double-count
// ├── 00350000  Golden: monotonic minimum at left edge
// ├── 00360000  Golden: all-equal rightmost-of-window, one increment per window
// └── 00370000  Golden: all-zero produces no scores

// =========================================================================
// Issue 1 — Hash Mismatch Between Reference Implementation and Go Implementation
// https://github.com/eciavatta/sdhash/issues/1
// =========================================================================

// ---------------------------------------------------------------------------
// 00010000  Stream and DD parsed score in range
// ---------------------------------------------------------------------------

func TestIssue1_StreamAndDDParsedScoreInRange(t *testing.T) {
	t.Parallel()

	streamBytes, err := os.ReadFile("testdata/issue1.stream")
	mustNoError(t, err)
	ddBytes, err := os.ReadFile("testdata/issue1.dd")
	mustNoError(t, err)

	streamSD, err := ParseSdbfFromString(string(streamBytes))
	mustNoError(t, err, "ParseSdbfFromString must succeed on issue1.stream")

	ddSD, err := ParseSdbfFromString(string(ddBytes))
	mustNoError(t, err, "ParseSdbfFromString must succeed on issue1.dd")

	var score int
	var ok bool
	checkNotPanics(t, func() { score, ok = streamSD.Compare(ddSD) }, "cross-mode Compare must not panic")
	checkTrue(t, ok, "cross-mode Compare must be meaningful")
	checkAtLeast(t, score, 0, "cross-mode score must be >= 0")
	checkAtMost(t, score, 100, "cross-mode score must be <= 100")
}

// ---------------------------------------------------------------------------
// 00020000  Round-trip stream reference
// ---------------------------------------------------------------------------

func TestIssue1_RoundTrip_StreamReference(t *testing.T) {
	t.Parallel()
	rawBytes, err := os.ReadFile("testdata/issue1.stream")
	mustNoError(t, err)
	raw := strings.TrimRight(string(rawBytes), "\r\n") + "\n"

	sd, err := ParseSdbfFromString(raw)
	mustNoError(t, err)

	checkEqual(t, raw, sd.String(), "ParseSdbfFromString→String must be identity for issue1.stream")
	score, ok := sd.Compare(sd)
	checkTrue(t, ok, "self-comparison of parsed issue1.stream digest must be comparable")
	checkEqual(t, 100, score, "self-comparison of parsed issue1.stream digest must be 100")
}

// ---------------------------------------------------------------------------
// 00030000  Round-trip DD reference
// ---------------------------------------------------------------------------

func TestIssue1_RoundTrip_DDReference(t *testing.T) {
	t.Parallel()
	rawBytes, err := os.ReadFile("testdata/issue1.dd")
	mustNoError(t, err)
	raw := strings.TrimRight(string(rawBytes), "\r\n") + "\n"

	sd, err := ParseSdbfFromString(raw)
	mustNoError(t, err)

	checkEqual(t, raw, sd.String(), "ParseSdbfFromString→String must be identity for issue1.dd")
	score, ok := sd.Compare(sd)
	checkTrue(t, ok, "self-comparison of parsed issue1.dd digest must be comparable")
	checkEqual(t, 100, score, "self-comparison of parsed issue1.dd digest must be 100")
}

// =========================================================================
// Issue 2 — Feature density detection for degenerate stream mode digests
// https://github.com/malwarology/sdhash/issues/2
// =========================================================================

// ---------------------------------------------------------------------------
// 00040000  DD mode no false positive
// ---------------------------------------------------------------------------

// TestIssue2_DDModeNoFalsePositive verifies that DD mode does not produce
// the same false positive for the issue 2 samples.
func TestIssue2_DDModeNoFalsePositive(t *testing.T) {
	t.Parallel()

	dataA := decryptTestFile(t, "testdata/issue2a.bin.enc")
	dataB := decryptTestFile(t, "testdata/issue2b.bin.enc")

	ddA := ddDigest(t, dataA, 65536)
	ddB := ddDigest(t, dataB, 65536)

	score, ok := ddA.Compare(ddB)
	checkTrue(t, ok, "issue2 DD comparison must be comparable")
	checkEqual(t, 0, score,
		"issue2 DD comparison must be 0")
}

// =========================================================================
// Issue 3 — Unbounded goroutine spawning in generateBlockSdbf
// https://github.com/malwarology/sdhash/issues/3
// =========================================================================

// ---------------------------------------------------------------------------
// 00050000  High block count DD mode
// ---------------------------------------------------------------------------

// TestIssue3_HighBlockCountDDMode verifies that computing a DD digest with a
// small block size (1024 bytes) over a 1 MiB buffer — producing ~1024 blocks —
// completes correctly without unbounded goroutine spawning. Without the
// semaphore fix in generateBlockSdbf, this configuration spawns 1024+
// goroutines simultaneously.
func TestIssue3_HighBlockCountDDMode(t *testing.T) {
	t.Parallel()

	data := randomBuf(1<<20, 50, 50)

	factory, err := New(data)
	mustNoError(t, err)

	const ddBlockSize = 1024
	sd, err := factory.WithBlockSize(ddBlockSize).Compute()
	mustNoError(t, err)

	score, ok := sd.Compare(sd)
	checkTrue(t, ok, "self-comparison must be comparable")
	checkEqual(t, 100, score, "self-comparison must return 100")
}

// =========================================================================
// Issue 4 — Unbounded memory allocation in ParseSdbfFromString
// https://github.com/malwarology/sdhash/issues/4
// =========================================================================

// ---------------------------------------------------------------------------
// 00060000  Parse oversized bfCount
// ---------------------------------------------------------------------------

// TestIssue4_ParseOversizedBfCount verifies that a digest string with a
// bfCount large enough to exceed the 256 MiB allocation limit is rejected
// by ParseSdbfFromString rather than causing an OOM panic.
func TestIssue4_ParseOversizedBfCount(t *testing.T) {
	t.Parallel()

	// bfCount of 999999999 with the default bfSize of 256 bytes would require
	// ~238 GiB, far exceeding the 256 MiB cap.
	digest := "sdbf:03:1:-:1048576:sha1:256:5:7ff:160:999999999:100:"

	_, err := ParseSdbfFromString(digest)
	checkError(t, err,
		"ParseSdbfFromString must return an error for a bfCount that exceeds the allocation limit (regression: issue #4)")
}

// ---------------------------------------------------------------------------
// 00070000  Parse zero bfSize
// ---------------------------------------------------------------------------

// TestIssue4_ParseZeroBfSize verifies that a digest string with bfSize set to
// zero is rejected by ParseSdbfFromString rather than causing a divide-by-zero
// panic inside the allocation sanity check.
func TestIssue4_ParseZeroBfSize(t *testing.T) {
	t.Parallel()

	// bfSize of 0 must be caught before the allocation check to prevent
	// a divide-by-zero when computing maxBfAlloc/bfSize.
	digest := "sdbf:03:1:-:1048576:sha1:0:5:7ff:160:100:100:"

	_, err := ParseSdbfFromString(digest)
	checkError(t, err,
		"ParseSdbfFromString must return an error for a bfSize of zero (regression: issue #4)")
}

// =========================================================================
// Issue 10 — ParseSdbfFromString panics on truncated base64 payload
// https://github.com/malwarology/sdhash/issues/10
// =========================================================================

// ---------------------------------------------------------------------------
// 00080000  Parse truncated stream buffer
// ---------------------------------------------------------------------------

// TestIssue10_ParseTruncatedStreamBuffer verifies that a stream digest whose
// base64 payload decodes to fewer bytes than bfCount × bfSize is rejected by
// ParseSdbfFromString rather than causing a slice-bounds panic in computeHamming.
func TestIssue10_ParseTruncatedStreamBuffer(t *testing.T) {
	t.Parallel()

	// bfCount=1, bfSize=256: the buffer must be 256 bytes, but we supply only 128.
	payload := base64.StdEncoding.EncodeToString(make([]byte, 128))
	digest := fmt.Sprintf("sdbf:03:1:-:1048576:sha1:256:5:7ff:160:1:100:%s\n", payload)

	_, err := ParseSdbfFromString(digest)
	checkError(t, err,
		"ParseSdbfFromString must return an error when the base64 payload decodes to fewer bytes than bfCount × bfSize (regression: issue #10)")
}

// ---------------------------------------------------------------------------
// 00090000  Parse stream lastCount exceeds maxElem
// ---------------------------------------------------------------------------

// TestIssue10_ParseStreamLastCountExceedsMaxElem verifies that a stream digest
// where lastCount is greater than maxElem is rejected by ParseSdbfFromString.
func TestIssue10_ParseStreamLastCountExceedsMaxElem(t *testing.T) {
	t.Parallel()

	// maxElem=160, lastCount=999: lastCount must not exceed maxElem.
	// The buffer is a valid 256-byte payload so the length check passes first.
	payload := base64.StdEncoding.EncodeToString(make([]byte, 256))
	digest := fmt.Sprintf("sdbf:03:1:-:1048576:sha1:256:5:7ff:160:1:999:%s\n", payload)

	_, err := ParseSdbfFromString(digest)
	checkError(t, err,
		"ParseSdbfFromString must return an error when lastCount exceeds maxElem (regression: issue #10)")
}

// ---------------------------------------------------------------------------
// 00100000  Parse DD block too short
// ---------------------------------------------------------------------------

// TestIssue10_ParseDDBlockTooShort verifies that a DD digest where a block's
// base64 decodes to fewer bytes than bfSize is rejected by ParseSdbfFromString
// rather than leaving the destination slice partially filled.
func TestIssue10_ParseDDBlockTooShort(t *testing.T) {
	t.Parallel()

	// bfCount=1, bfSize=256, elemCount=0x64 (100 ≤ maxElem=160): the block
	// payload must be 256 bytes, but we supply only 128.
	payload := base64.StdEncoding.EncodeToString(make([]byte, 128))
	digest := fmt.Sprintf("sdbf-dd:03:1:-:1048576:sha1:256:5:7ff:160:1:65536:64:%s\n", payload)

	_, err := ParseSdbfFromString(digest)
	checkError(t, err,
		"ParseSdbfFromString must return an error when a DD block's base64 decodes to fewer bytes than bfSize (regression: issue #10)")
}

// ---------------------------------------------------------------------------
// 00110000  Parse DD element count exceeds maxElem
// ---------------------------------------------------------------------------

// TestIssue10_ParseDDElemCountExceedsMaxElem verifies that a DD digest where
// a block's element count exceeds maxElem is rejected by ParseSdbfFromString.
func TestIssue10_ParseDDElemCountExceedsMaxElem(t *testing.T) {
	t.Parallel()

	// maxElem=192 (0xc0), elemCount=0xff (255): 255 > 192 must be rejected.
	// The block payload is a valid 256-byte buffer so the length check would pass.
	payload := base64.StdEncoding.EncodeToString(make([]byte, 256))
	digest := fmt.Sprintf("sdbf-dd:03:1:-:1048576:sha1:256:5:7ff:192:1:65536:ff:%s\n", payload)

	_, err := ParseSdbfFromString(digest)
	checkError(t, err,
		"ParseSdbfFromString must return an error when a DD block element count exceeds maxElem (regression: issue #10)")
}

// =========================================================================
// Issue 11 — BfSize exported as mutable var but hardwired to 256 throughout
// https://github.com/malwarology/sdhash/issues/11
// =========================================================================

// ---------------------------------------------------------------------------
// 00120000  Parse unsupported bfSize
// ---------------------------------------------------------------------------

// TestIssue11_ParseUnsupportedBfSize verifies that a stream digest string with
// bfSize set to 512 instead of the only supported value (256) is rejected by
// ParseSdbfFromString. The rest of the digest is structurally valid: bfCount=1,
// maxElem=160, lastCount=100, and a 512-byte base64 payload that satisfies the
// bfCount × bfSize length check — ensuring the rejection is caused solely by
// the unsupported bfSize value and not by any other validation.
func TestIssue11_ParseUnsupportedBfSize(t *testing.T) {
	t.Parallel()

	// bfSize=512: the implementation is hardwired to 256-byte bloom filters, so
	// any other value must be rejected before any buffer is allocated or decoded.
	payload := base64.StdEncoding.EncodeToString(make([]byte, 512))
	digest := fmt.Sprintf("sdbf:03:1:-:1048576:sha1:512:5:7ff:160:1:100:%s\n", payload)

	_, err := ParseSdbfFromString(digest)
	checkError(t, err,
		"ParseSdbfFromString must return an error for a bfSize other than 256 (regression: issue #11)")
}

// =========================================================================
// Issue 14 — New retains caller's slice without copying
// https://github.com/malwarology/sdhash/issues/14
// =========================================================================

// ---------------------------------------------------------------------------
// 00130000  Buffer mutation after factory creation
// ---------------------------------------------------------------------------

// TestIssue14_BufferMutationAfterFactory verifies that mutating the original
// buffer after calling New does not affect the digest produced
// by the factory. Without a defensive copy inside New, zeroing
// the buffer between factory creation and Compute causes both factories to
// produce identical digests even though one was created from random data.
func TestIssue14_BufferMutationAfterFactory(t *testing.T) {
	t.Parallel()

	buf := randomBuf(1<<20, 60, 60)

	factory, err := New(buf)
	mustNoError(t, err)

	sd, err := factory.Compute()
	mustNoError(t, err)
	first := sd.String()

	// Zero out the original buffer to simulate a caller reusing or releasing it.
	clear(buf)

	factory2, err := New(buf)
	mustNoError(t, err)

	sd2, err := factory2.Compute()
	mustNoError(t, err)
	second := sd2.String()

	if first == second {
		t.Errorf("digest computed before buffer mutation equals digest computed after: factory did not copy the buffer (regression: issue #14)")
	}
}

// =========================================================================
// Issue 15 — DD parsing fails on digests without trailing newline
// https://github.com/malwarology/sdhash/issues/15
// =========================================================================

// ---------------------------------------------------------------------------
// 00140000  DD parse without trailing newline
// ---------------------------------------------------------------------------

// TestIssue15_DDParseWithoutTrailingNewline verifies that ParseSdbfFromString
// correctly decodes a DD digest string that has no trailing newline. Without
// the EOF-tolerant fix, the last byte of the final block's base64 payload is
// stripped along with the missing delimiter, causing a base64 decode error or
// an incorrect bloom filter.
func TestIssue15_DDParseWithoutTrailingNewline(t *testing.T) {
	t.Parallel()

	buf := randomBuf(1<<20, 70, 70)
	sd := ddDigest(t, buf, 65536)

	stripped := strings.TrimRight(sd.String(), "\n")
	checkTrue(t, !strings.HasSuffix(stripped, "\n"),
		"stripped digest must not end with a newline")

	parsed, err := ParseSdbfFromString(stripped)
	mustNoError(t, err, "ParseSdbfFromString must succeed on a DD digest without a trailing newline (regression: issue #15)")

	checkEqual(t, sd.String(), parsed.String(),
		"parsed digest String() must equal the original (regression: issue #15)")
	score, ok := parsed.Compare(parsed)
	checkTrue(t, ok, "self-comparison of parsed digest must be comparable (regression: issue #15)")
	checkEqual(t, 100, score, "self-comparison of parsed digest must return 100 (regression: issue #15)")
}

// =========================================================================
// Issue 17 — Compare panics on nil or foreign Sdbf implementation
// https://github.com/malwarology/sdhash/issues/17
// =========================================================================

// ---------------------------------------------------------------------------
// 00150000  Compare with nil Sdbf returns -1
// ---------------------------------------------------------------------------

// TestIssue17_CompareNilSdbf verifies that calling Compare with a nil Sdbf
// argument returns -1 instead of panicking. Without a nil guard inside
// Compare, passing nil causes a nil-pointer dereference when the
// implementation attempts to access the argument's fields.
func TestIssue17_CompareNilSdbf(t *testing.T) {
	t.Parallel()

	buf := randomBuf(1<<20, 80, 80)
	sd := streamDigest(t, buf)

	var ok bool
	checkNotPanics(t, func() { _, ok = sd.Compare(nil) },
		"Compare(nil) must not panic (regression: issue #17)")
	checkTrue(t, !ok,
		"Compare(nil) must not be comparable (regression: issue #17)")
}

// ---------------------------------------------------------------------------
// 00160000  Compare with foreign Sdbf implementation returns -1
// ---------------------------------------------------------------------------

// foreignSdbfImpl is a minimal Sdbf implementation used only by
// TestIssue17_CompareForeignImpl. It satisfies the Sdbf interface but is not
// the internal *sdbf type, so a type-assertion guard inside Compare must
// handle it gracefully rather than panicking.
type foreignSdbfImpl struct{}

func (f *foreignSdbfImpl) FilterSize() uint64       { return 0 }
func (f *foreignSdbfImpl) InputSize() uint64        { return 0 }
func (f *foreignSdbfImpl) FilterCount() uint32      { return 0 }
func (f *foreignSdbfImpl) Compare(Sdbf) (int, bool) { return 0, false }
func (f *foreignSdbfImpl) String() string           { return "" }
func (f *foreignSdbfImpl) FeatureDensity() float64  { return 0 }

// TestIssue17_CompareForeignImpl verifies that calling Compare with a foreign
// Sdbf implementation — one that satisfies the interface but is not the
// internal *sdbf type — returns -1 instead of panicking. Without a type-assertion
// guard inside Compare, a type assertion to *sdbf on the foreign
// value panics at runtime.
func TestIssue17_CompareForeignImpl(t *testing.T) {
	t.Parallel()

	buf := randomBuf(1<<20, 81, 81)
	sd := streamDigest(t, buf)

	foreign := &foreignSdbfImpl{}

	var ok bool
	checkNotPanics(t, func() { _, ok = sd.Compare(foreign) },
		"Compare with a foreign Sdbf implementation must not panic (regression: issue #17)")
	checkTrue(t, !ok,
		"Compare with a foreign Sdbf implementation must not be comparable (regression: issue #17)")
}

// =========================================================================
// Issue 19 — Unconstrained maxElem enables uint32 overflow in Compare
// https://github.com/malwarology/sdhash/issues/19
// =========================================================================

// ---------------------------------------------------------------------------
// 00170000  Parse maxElem overflow (uint32 wraparound)
// ---------------------------------------------------------------------------

// TestIssue19_ParseMaxElemOverflow verifies that a stream digest string with
// maxElem set to 2147483649 (0x80000001) is rejected by ParseSdbfFromString.
// Without an upper-bound check, the value is silently truncated to uint32,
// causing arithmetic overflow in the scoring path that produces an
// out-of-bounds index into cutoffs256 (149 entries) and panics.
func TestIssue19_ParseMaxElemOverflow(t *testing.T) {
	t.Parallel()

	// maxElem=2147483649 (0x80000001) overflows uint32 arithmetic in the
	// scoring path. The buffer is a valid 512-byte payload (bfCount=2,
	// bfSize=256) so all other validation checks would pass without the fix.
	payload := base64.StdEncoding.EncodeToString(make([]byte, 2*256))
	digest := fmt.Sprintf("sdbf:03:1:-:1048576:sha1:256:5:7ff:2147483649:2:0:%s\n", payload)

	_, err := ParseSdbfFromString(digest)
	checkError(t, err,
		"ParseSdbfFromString must return an error for a maxElem that overflows uint32 arithmetic (regression: issue #19)")
}

// ---------------------------------------------------------------------------
// 00180000  Parse maxElem zero
// ---------------------------------------------------------------------------

// TestIssue19_ParseMaxElemZero verifies that a stream digest string with
// maxElem set to 0 is rejected by ParseSdbfFromString. A zero maxElem is
// semantically meaningless (no elements can be inserted) and would produce
// a divide-by-zero or scoring anomaly if passed through unchecked.
func TestIssue19_ParseMaxElemZero(t *testing.T) {
	t.Parallel()

	// maxElem=0: zero max elements is invalid. The buffer is a valid 256-byte
	// payload (bfCount=1, bfSize=256) so all other validation checks would
	// pass without the fix.
	payload := base64.StdEncoding.EncodeToString(make([]byte, 256))
	digest := fmt.Sprintf("sdbf:03:1:-:1048576:sha1:256:5:7ff:0:1:0:%s\n", payload)

	_, err := ParseSdbfFromString(digest)
	checkError(t, err,
		"ParseSdbfFromString must return an error for a maxElem of zero (regression: issue #19)")
}

// =========================================================================
// Issue 20 — Inner while loop evaluates array access before bounds guard
// https://github.com/malwarology/sdhash/issues/20
// =========================================================================

// ---------------------------------------------------------------------------
// 00190000  generateChunkScores inner while loop OOB
// ---------------------------------------------------------------------------

// TestIssue20_ChunkScoresInnerWhileOOB verifies that generateChunkScores
// completes without an out-of-bounds panic when the inner while loop runs
// near the end of the chunk. Without the fix, the loop evaluates
// chunkRanks[i+popWin] before the bounds guard i < chunkSize-popWin,
// causing a panic when i+popWin reaches the end of the slice. The crafted
// ranks place the window minimum at index 189 so that the inner while loop
// is entered and advances i toward the slice boundary.
func TestIssue20_ChunkScoresInnerWhileOOB(t *testing.T) {
	t.Parallel()

	chunkRanks := make([]uint16, 192)
	chunkScores := make([]uint16, 192)

	for i := range chunkRanks {
		chunkRanks[i] = 50
	}
	chunkRanks[189] = 10

	sd := &sdbf{popWinSize: popWinSize}

	checkNotPanics(t, func() { sd.generateChunkScores(chunkRanks, 192, chunkScores, nil) },
		"generateChunkScores must not panic near the end of the chunk (regression: issue #20)")
}

// =========================================================================
// Issue 21 — WithBlockSize accepts values below PopWinSize causing underflow panic
// https://github.com/malwarology/sdhash/issues/21
// =========================================================================

// ---------------------------------------------------------------------------
// 00200000  Small block size uint64 underflow
// ---------------------------------------------------------------------------

// TestIssue21_SmallBlockSizeUnderflow verifies that passing a block size below
// PopWinSize (64) to WithBlockSize causes Compute to return an error rather than
// panicking. Without a validation check in createSdbf, the histogram loop in
// generateChunkScores computes chunkSize-popWin as a uint64 subtraction that
// underflows to a huge value, causing an out-of-bounds index and a goroutine
// panic that terminates the process.
func TestIssue21_SmallBlockSizeUnderflow(t *testing.T) {
	t.Parallel()

	buf := randomBuf(1<<20, 90, 90)

	factory, err := New(buf)
	mustNoError(t, err)

	var computeErr error
	checkNotPanics(t, func() {
		_, computeErr = factory.WithBlockSize(32).Compute()
	}, "WithBlockSize(32).Compute() must not panic (regression: issue #21)")
	checkError(t, computeErr,
		"WithBlockSize(32).Compute() must return an error when block size is below PopWinSize (regression: issue #21)")
}

// =========================================================================
// Issue 31 — ddBlockSize silently truncated from uint64 to uint32
// https://github.com/malwarology/sdhash/issues/31
// =========================================================================

// ---------------------------------------------------------------------------
// 00210000  DD ddBlockSize uint64 to uint32 truncation
// ---------------------------------------------------------------------------

// TestIssue31_DdBlockSizeTruncation verifies that a DD digest string with
// ddBlockSize set to 4294967552 (0x100000100, which truncates to 256 as uint32)
// is rejected by ParseSdbfFromString. Without a range check, the value is
// silently narrowed when stored in a uint32 field, causing the parsed digest
// to carry an incorrect block size that later produces corrupt Compare results
// or allows crafted input to bypass block-size validation.
func TestIssue31_DdBlockSizeTruncation(t *testing.T) {
	t.Parallel()

	// ddBlockSize=4294967552 (0x100000100) truncates to 256 when stored as
	// uint32. bfCount=1, bfSize=256, maxElem=192, elemCount=0xc0 (192 ≤
	// maxElem=192): all other validation checks would pass without the fix.
	payload := base64.StdEncoding.EncodeToString(make([]byte, 256))
	digest := fmt.Sprintf("sdbf-dd:03:1:-:1048576:sha1:256:5:7ff:192:1:4294967552:c0:%s\n", payload)

	_, err := ParseSdbfFromString(digest)
	checkError(t, err,
		"ParseSdbfFromString must return an error for a ddBlockSize that overflows uint32 (regression: issue #31)")
}

// =========================================================================
// Issue 43 — sdbfScore mixes -1 sentinel returns from sdbfMaxScore into the score sum, corrupting results
// https://github.com/malwarology/sdhash/issues/43
// =========================================================================

// ---------------------------------------------------------------------------
// 00220000  Stream mode degenerate pair returns score 0 and ok false
// ---------------------------------------------------------------------------

// TestIssue43_StreamDegeneratePairScore verifies that comparing two stream
// digests where some filters have no scoreable target returns a clean
// (score, true) result. Pre-fix, the -1 sentinels returned by sdbfMaxScore
// for no-scoreable-target filters were summed directly into scoreSum,
// pushing it negative and causing Compare to incorrectly report the pair as
// incomparable (0, false). Post-fix, the -1 returns are excluded from both
// the sum and the denominator, the remaining valid filter comparisons are
// averaged correctly, and this pair's low real similarity is reported as
// (0, true). The regression signature is the ok flag: any reintroduction of
// the -1-accumulation bug will flip it back to false on this pair.
func TestIssue43_StreamDegeneratePairScore(t *testing.T) {
	t.Parallel()

	dataA := decryptTestFile(t, "testdata/issue43a.bin.enc")
	dataB := decryptTestFile(t, "testdata/issue43b.bin.enc")

	sdA := streamDigest(t, dataA)
	sdB := streamDigest(t, dataB)

	var score int
	var ok bool
	checkNotPanics(t, func() { score, ok = sdA.Compare(sdB) },
		"Compare must not panic on this pair (regression: issue #43)")
	checkTrue(t, ok,
		"Compare must return ok=true; pre-fix bug flipped it to false (regression: issue #43)")
	checkEqual(t, 0, score,
		"Compare must return score=0 for this pair (regression: issue #43)")
}

// ---------------------------------------------------------------------------
// 00230000  DD mode degenerate pair returns score 0 and ok false
// ---------------------------------------------------------------------------

// TestIssue43_DDDegeneratePairScore verifies the same sentinel-exclusion fix
// in DD (block-aligned) mode. Pre-fix, summing -1 sentinels into scoreSum
// flipped this pair to (0, false), falsely reporting it as incomparable.
// Post-fix, the -1 returns are properly excluded from both the sum and the
// denominator, and the pair's low real similarity is reported as (0, true).
// The regression signature is the ok flag: any reintroduction of the
// -1-accumulation bug will flip it back to false on this pair.
func TestIssue43_DDDegeneratePairScore(t *testing.T) {
	t.Parallel()

	const ddBlockSize = 1048576

	dataA := decryptTestFile(t, "testdata/issue43a.bin.enc")
	dataB := decryptTestFile(t, "testdata/issue43b.bin.enc")

	sdA := ddDigest(t, dataA, ddBlockSize)
	sdB := ddDigest(t, dataB, ddBlockSize)

	var score int
	var ok bool
	checkNotPanics(t, func() { score, ok = sdA.Compare(sdB) },
		"Compare must not panic on this pair (regression: issue #43)")
	checkTrue(t, ok,
		"Compare must return ok=true; pre-fix bug flipped it to false (regression: issue #43)")
	checkEqual(t, 0, score,
		"Compare must return score=0 for this pair (regression: issue #43)")
}

// =========================================================================
// Issue 57 — generateChunkScores double-counts positions in equal-rank runs
//    https://github.com/malwarology/sdhash/issues/57
//
// The pre-fix two-block selector double-counted positions in runs of equal
// ranks. The fixed function increments exactly one position per window, chosen
// by the per-window rule captured in bruteScoresFirstRun. The reference-
// equivalence tests assert the production function matches that spec across
// adversarial inputs; the golden tests pin the exact output for crafted cases.
// =========================================================================

// ---------------------------------------------------------------------------
// 00240000  Reference equivalence: high-entropy inputs
// ---------------------------------------------------------------------------

func TestIssue57_Equivalence_HighEntropy(t *testing.T) {
	t.Parallel()
	for seed := uint64(1); seed <= 20; seed++ {
		for _, ranks := range rankCasesFor("highentropy", seed) {
			checkChunkScoresMatchSpec(t, ranks, fmt.Sprintf("high-entropy seed=%d n=%d (regression: issue #57)", seed, len(ranks)))
		}
	}
}

// ---------------------------------------------------------------------------
// 00250000  Reference equivalence: tie-heavy inputs
// ---------------------------------------------------------------------------

func TestIssue57_Equivalence_TieHeavy(t *testing.T) {
	t.Parallel()
	for seed := uint64(1); seed <= 20; seed++ {
		for _, ranks := range rankCasesFor("tieheavy", seed) {
			checkChunkScoresMatchSpec(t, ranks, fmt.Sprintf("tie-heavy seed=%d n=%d (regression: issue #57)", seed, len(ranks)))
		}
	}
}

// ---------------------------------------------------------------------------
// 00260000  Reference equivalence: zero-laden inputs
// ---------------------------------------------------------------------------

func TestIssue57_Equivalence_ZeroLaden(t *testing.T) {
	t.Parallel()
	for seed := uint64(1); seed <= 20; seed++ {
		for _, ranks := range rankCasesFor("zeroladen", seed) {
			checkChunkScoresMatchSpec(t, ranks, fmt.Sprintf("zero-laden seed=%d n=%d (regression: issue #57)", seed, len(ranks)))
		}
	}
}

// ---------------------------------------------------------------------------
// 00270000  Reference equivalence: persistent-min inputs
// ---------------------------------------------------------------------------

func TestIssue57_Equivalence_PersistentMin(t *testing.T) {
	t.Parallel()
	for seed := uint64(1); seed <= 20; seed++ {
		for _, ranks := range rankCasesFor("persistmin", seed) {
			checkChunkScoresMatchSpec(t, ranks, fmt.Sprintf("persistent-min seed=%d n=%d (regression: issue #57)", seed, len(ranks)))
		}
	}
}

// ---------------------------------------------------------------------------
// 00280000  Reference equivalence: monotonic inputs
// ---------------------------------------------------------------------------

func TestIssue57_Equivalence_Monotonic(t *testing.T) {
	t.Parallel()
	for seed := uint64(1); seed <= 20; seed++ {
		for _, ranks := range rankCasesFor("monotonic", seed) {
			checkChunkScoresMatchSpec(t, ranks, fmt.Sprintf("monotonic seed=%d n=%d (regression: issue #57)", seed, len(ranks)))
		}
	}
}

// ---------------------------------------------------------------------------
// 00290000  Reference equivalence: all-equal inputs
// ---------------------------------------------------------------------------

func TestIssue57_Equivalence_AllEqual(t *testing.T) {
	t.Parallel()
	for seed := uint64(1); seed <= 20; seed++ {
		for _, ranks := range rankCasesFor("allequal", seed) {
			checkChunkScoresMatchSpec(t, ranks, fmt.Sprintf("all-equal seed=%d n=%d (regression: issue #57)", seed, len(ranks)))
		}
	}
}

// ---------------------------------------------------------------------------
// 00300000  Reference equivalence: all-zero inputs
// ---------------------------------------------------------------------------

func TestIssue57_Equivalence_AllZero(t *testing.T) {
	t.Parallel()
	for seed := uint64(1); seed <= 20; seed++ {
		for _, ranks := range rankCasesFor("allzero", seed) {
			checkChunkScoresMatchSpec(t, ranks, fmt.Sprintf("all-zero seed=%d n=%d (regression: issue #57)", seed, len(ranks)))
		}
	}
}

// ---------------------------------------------------------------------------
// 00310000  Golden: high-entropy single interior minimum
// ---------------------------------------------------------------------------

func TestIssue57_Golden_HighEntropy(t *testing.T) {
	t.Parallel()
	// Distinct values with a single clear minimum at position 32.
	ranks := make([]uint16, 65)
	for i := range ranks {
		ranks[i] = uint16(100 + i)
	}
	ranks[32] = 1
	want := make([]uint16, 65)
	want[32] = 1
	checkChunkScoresGolden(t, ranks, want, "high-entropy single interior minimum (regression: issue #57)")
}

// ---------------------------------------------------------------------------
// 00320000  Golden: tie-heavy rightmost-of-first-run selection
// ---------------------------------------------------------------------------

func TestIssue57_Golden_TieHeavy(t *testing.T) {
	t.Parallel()
	// Minimum value 2 appears as a consecutive run at 5,6,7 and again,
	// non-consecutively, at 20. The rule selects the rightmost of the FIRST
	// run (position 7); the latter, non-adjacent 2 is ignored.
	ranks := make([]uint16, 65)
	for i := range ranks {
		ranks[i] = 9
	}
	ranks[5], ranks[6], ranks[7] = 2, 2, 2
	ranks[20] = 2
	want := make([]uint16, 65)
	want[7] = 1
	checkChunkScoresGolden(t, ranks, want, "tie-heavy rightmost-of-first-run (regression: issue #57)")
}

// ---------------------------------------------------------------------------
// 00330000  Golden: zero-laden zero-minimum skipped
// ---------------------------------------------------------------------------

func TestIssue57_Golden_ZeroLaden(t *testing.T) {
	t.Parallel()
	// The array minimum is a zero at position 10, but zeros are never selected;
	// the minimum NONZERO rank (3 at position 30) wins instead.
	ranks := make([]uint16, 65)
	for i := range ranks {
		ranks[i] = 9
	}
	ranks[10] = 0
	ranks[30] = 3
	want := make([]uint16, 65)
	want[30] = 1
	checkChunkScoresGolden(t, ranks, want, "zero-laden zero-minimum skipped (regression: issue #57)")
}

// ---------------------------------------------------------------------------
// 00340000  Golden: persistent-min single position, no double-count
// ---------------------------------------------------------------------------

func TestIssue57_Golden_PersistentMin(t *testing.T) {
	t.Parallel()
	// A run of the minimum value (1) at positions 30..40 sits fully inside all
	// six windows. Each window selects position 40 (rightmost of the run) and
	// increments it exactly once: the pre-fix double-count would inflate this.
	ranks := make([]uint16, 70)
	for i := range ranks {
		ranks[i] = 9
	}
	for i := 30; i <= 40; i++ {
		ranks[i] = 1
	}
	want := make([]uint16, 70)
	want[40] = 6
	checkChunkScoresGolden(t, ranks, want, "persistent-min single position no double-count (regression: issue #57)")
}

// ---------------------------------------------------------------------------
// 00350000  Golden: monotonic minimum at left edge
// ---------------------------------------------------------------------------

func TestIssue57_Golden_Monotonic(t *testing.T) {
	t.Parallel()
	// Strictly increasing ranks: each window's minimum is its left-edge element.
	ranks := make([]uint16, 66)
	for i := range ranks {
		ranks[i] = uint16(i + 1)
	}
	want := make([]uint16, 66)
	want[0] = 1
	want[1] = 1
	checkChunkScoresGolden(t, ranks, want, "monotonic minimum at left edge (regression: issue #57)")
}

// ---------------------------------------------------------------------------
// 00360000  Golden: all-equal rightmost-of-window, one increment per window
// ---------------------------------------------------------------------------

func TestIssue57_Golden_AllEqual(t *testing.T) {
	t.Parallel()
	// All ranks equal: each window's first run spans the whole window, so its
	// rightmost element is selected. Two windows -> positions 63 and 64, one
	// increment each (the pre-fix bug produced [.,.,1,0,2] here).
	ranks := make([]uint16, 66)
	for i := range ranks {
		ranks[i] = 7
	}
	want := make([]uint16, 66)
	want[63] = 1
	want[64] = 1
	checkChunkScoresGolden(t, ranks, want, "all-equal rightmost-of-window (regression: issue #57)")
}

// ---------------------------------------------------------------------------
// 00370000  Golden: all-zero produces no scores
// ---------------------------------------------------------------------------

func TestIssue57_Golden_AllZero(t *testing.T) {
	t.Parallel()
	// Zero ranks are never selected, so no position is ever incremented.
	ranks := make([]uint16, 66)
	want := make([]uint16, 66)
	checkChunkScoresGolden(t, ranks, want, "all-zero produces no scores (regression: issue #57)")
}
